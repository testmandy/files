package com.imooc.MRAutoSpace.utils.http;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.io.IOUtils;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpEntityEnclosingRequestBase;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.log4j.Logger;

import com.imooc.MRAutoSpace.model.http.HttpClientRequest;
import com.imooc.MRAutoSpace.model.http.HttpClientResponse;

public class HttpClientUtil {
	private static Logger logger = Logger.getLogger(HttpClientUtil.class);
	private CloseableHttpClient httpClient;
	
	// 定义最终需要的方法
	public static HttpClientResponse doGet(HttpClientRequest httpClientRequest){
		HttpClientUtil httpClientUtil = new HttpClientUtil();
		httpClientUtil.init();
		HttpGet httpGet = new HttpGet(httpClientRequest.getUrl());
		return httpClientUtil.sendRequest(httpGet, httpClientRequest);
	}
	
	public static HttpClientResponse doPost(HttpClientRequest httpClientRequest){
		HttpClientUtil httpClientUtil = new HttpClientUtil();
		httpClientUtil.init();
		HttpPost httpPost = new HttpPost(httpClientRequest.getUrl());
		return httpClientUtil.sendRequest(httpPost, httpClientRequest);
	}
	
	public static HttpClientResponse doDelete(HttpClientRequest httpClientRequest){
		HttpClientUtil httpClientUtil = new HttpClientUtil();
		httpClientUtil.init();
		HttpDelete httpDelete = new HttpDelete(httpClientRequest.getUrl());
		return httpClientUtil.sendRequest(httpDelete, httpClientRequest);
	}
	
	public static HttpClientResponse doPut(HttpClientRequest httpClientRequest){
		HttpClientUtil httpClientUtil = new HttpClientUtil();
		httpClientUtil.init();
		HttpPut httpPut = new HttpPut(httpClientRequest.getUrl());
		return httpClientUtil.sendRequest(httpPut, httpClientRequest);
	}
	
	// 初始化连接
	private void init(){
		httpClient = HttpClientBuilder.create().build();
		logger.info("Start init http connection.");
	}
	
	// 声明send方法
	private HttpClientResponse sendRequest(HttpRequestBase httpRequestBase, HttpClientRequest httpClientRequest){
		
		HttpClientResponse httpClientResponse = new HttpClientResponse();
		String encodingofBody = "ISO-8859-1";
//		String url = httpClientRequest.getUrl();
//		HttpPost post = new HttpPost(url);
		Map<String, String> requestHeaders = httpClientRequest.getHeaders();
		for ( String key : requestHeaders.keySet()){
			httpRequestBase.setHeader(key, requestHeaders.get(key));
			if (key.toLowerCase().equals("content-type")){
				String contentType = requestHeaders.get(key);
				if (contentType.split(":").length >= 2){
					encodingofBody = contentType.split(":")[1].split("=")[1];
				}
			}
		}
//		try {
//			if(httpRequestBase instanceof HttpEntityEnclosingRequestBase){
//				((HttpEntityEnclosingRequestBase) httpRequestBase).setEntity(new StringEntity(httpClientRequest.getBody()));				
//			}
//			
//		} catch (UnsupportedEncodingException e) {
//			logger.error("This encoding is not supported.");
//			logger.error(e.getMessage());
//		}
		try {
			CloseableHttpResponse response = httpClient.execute(httpRequestBase);
			String statusCode = response.getStatusLine().toString().split(" ")[1];
			logger.info(statusCode);
			httpClientResponse.setStatusCode(statusCode); 
			
			Header[] headers = response.getAllHeaders();
			Map<String, String> responseHeaders = new HashMap<String, String>();
			for (Header header:headers){
				logger.info(header.getName() + ": " + header.getValue());
				responseHeaders.put(header.getName(), header.getValue());
			}
			httpClientResponse.setHeaders(responseHeaders);
			
			HttpEntity entity = response.getEntity();
			String body = IOUtils.toString(entity.getContent());
			logger.info(body);
			httpClientResponse.setBody(body);
			
			this.close();
		} catch (ClientProtocolException e) {
			logger.error("This http protocol is not supported.");
			logger.error(e.getMessage());
		} catch (IOException e) {
			logger.error(e.getMessage());
		}
		return httpClientResponse;
	}
	
	// 声明close方法，关闭连接
	private void close(){
		try {
			httpClient.close();
			logger.info("Close http connection successfully!");
		} catch (IOException e) {
			logger.error("Close http connection failed.");
			logger.error(e.getMessage());

		}
	}

	public CloseableHttpClient getHttpClient() {
		return httpClient;
	}

	public void setHttpClient(CloseableHttpClient httpClient) {
		this.httpClient = httpClient;
	}

}
