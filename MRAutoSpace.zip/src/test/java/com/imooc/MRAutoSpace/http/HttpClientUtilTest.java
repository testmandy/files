package com.imooc.MRAutoSpace.http;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.imooc.MRAutoSpace.model.http.HttpClientRequest;
import com.imooc.MRAutoSpace.model.http.HttpClientResponse;
import com.imooc.MRAutoSpace.utils.http.HttpClientUtil;

public class HttpClientUtilTest {
	private static Logger logger = Logger.getLogger(HttpClientUtilTest.class);	
	
	@Test
	public void testMethod(){
		HttpClientRequest request = new HttpClientRequest();
		request.setUrl("http://localhost:19090/getClassName?name=value");
		Map<String, String> requestHeaders = new HashMap<String, String>();
		requestHeaders.put("name01", "value01");
		requestHeaders.put("name02", "value02");
		request.setHeaders(requestHeaders);
		
		HttpClientResponse response = HttpClientUtil.doGet(request);
		Assert.assertEquals("200", response.getStatusCode());
	}
	
	@Test
	public void testMethodPost(){
		HttpClientRequest request = new HttpClientRequest();
		request.setUrl("http://localhost:19090/getClassName?name=value");
		Map<String, String> requestHeaders = new HashMap<String, String>();
		requestHeaders.put("name01", "value01");
		requestHeaders.put("name02", "value02");
		request.setHeaders(requestHeaders);
		request.setBody("test body string");
		
		HttpClientResponse response = HttpClientUtil.doPost(request);
		Assert.assertEquals("{\"id\": \"\", \"className\": \"testClassName\"}", response.getBody());
	}

}
